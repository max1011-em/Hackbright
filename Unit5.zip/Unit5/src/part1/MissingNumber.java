package part1;

import java.util.HashMap;
import java.util.Map;

public class MissingNumber {
    public static void main(String[] args) {
        int[] nums = {2, 1, 4, 3, 6, 5, 7, 10, 9};
        System.out.println(missingNumber(nums,8));
    }
    public static int missingNumber(int[] nums, int max){
        HashMap<Integer,Integer> number = new HashMap<>();

        for(int i = 0; i < nums.length; i++) {
            if(number.containsKey(nums[i])) {
                number.put(nums[i],number.get(nums[i]) +1);
            } else {
                number.put(nums[i],1);
            }
        }
        System.out.println(number.containsKey(8));
        for(int i = 1; i <= max; i++) {
            if(!number.containsKey(i)) {
                System.out.println("test");
                System.out.println(i);
                return i;
            }
        }
        return 0;
    }
}
