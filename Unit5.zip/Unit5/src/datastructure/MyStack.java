package datastructure;

public class MyStack {
    private Node top;
    private Node bottom;
    private int length;

    public MyStack() {
        top = null;
        bottom = null;
        length = 0;
    }

}