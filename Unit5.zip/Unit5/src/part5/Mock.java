package part5;

public @interface Mock {
}
