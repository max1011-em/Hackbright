package part2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Part2 {
    public static void main(String[] args) {
        String sentence = "hi, the(re hi) (this) is the";
        System.out.println(balParentheses(sentence));

    }
    public static boolean balParentheses(String str) {
        ArrayList<Character> paren = new ArrayList<>();
        int result = 0;
        for(int i = 0; i < str.length(); i++) {
            if(str.charAt(i) == '(' || str.charAt(i) == ')') {
                paren.add(str.charAt(i));
            }
        }
        for(int i = 0; i < paren.size(); i+=2) {
            if(paren.get(i) == ')') {
                return false;
            } else if(paren.get(i) == '(' && paren.get(i+1) != ')') {
                return false;
            }
        }
        return true;
    }

    public static boolean balBracket(String str) {

        return true;
    }
}
