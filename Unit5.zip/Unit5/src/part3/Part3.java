package part3;

public class Part3 {
    /*
    1. Linked lists
    What is the runtime of this function? O(n)

    2. Insertion Sort Quick Sort Merge Sort
    What sorting algorithms have the best runtime efficiency? What are the scenarios for the best case, worst case, and average case runtime efficiency?
    - Quicksort
    - O(n log n) in the best case, O(n log n) in the average case, and O(n^2) in the worst case
    3. recursion
    */
    public int RecursiveIndex

    {

        public static int recursiveIndex ( int[] intArray, int num){

        return _recursiveIndex(intArray, num, 0);
    }

        public static int _recursiveIndex ( int[] intArray, int num, int index){
        if (index == intArray.length) {
            return -1;
        }

        if (num == intArray[index]) {
            return index;
        }

        return _recursiveIndex(intArray, num, index + 1);
    }

        public static void main (String[]args){
        int[] oneToTen = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.println(recursiveIndex(oneToTen, 7));

        // Example where it is not found
        System.out.println(recursiveIndex(oneToTen, 0));

    }
    }
}
