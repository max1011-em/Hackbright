package com.devmountain.noteApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
